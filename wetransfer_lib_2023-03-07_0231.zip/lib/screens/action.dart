import 'package:demo/models/chatmodule.dart';
import 'package:demo/screens/chat.dart';
import 'package:flutter/material.dart';

List<String> userNames = [
  'kowshik',
  'person',
  'person2',
  'person3',
  'person5',
];
List<String> time = [
  '11:11',
  '11:12',
  '11:14',
  '11:15',
  '11:13',
];
List<String> message = [
  'hai',
  'hello',
  'fine',
  'abt',
  'home',
];

class Custom extends StatelessWidget {
  Custom({super.key});

  List<chatModel> chats = List.generate(
      5,
      (index) => chatModel()
        ..userName = userNames[index]
        ..image =
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNjwqI9nmRm__p5XIWSZA86n4PJHjKPxUiS0wCvNx0FGEz1gbYqVjq9J0IGm5TnFQMKOo&usqp=CAU'
        ..message = message[index]
        ..time = time[index]);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.add),
      ),
      body: ListView(
        children: [
          ...List.generate(
            5,
            (index) => Chat(
              chatdata: chats[index],
            ),
          )
        ],
      ),
    );
  }
}
