import 'package:flutter/material.dart';

class Draw extends StatefulWidget {
  const Draw({super.key});

  @override
  State<Draw> createState() => _DrawState();
}

class _DrawState extends State<Draw> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: Image(
                height: 125,
                width: 125,
                image: NetworkImage(
                    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNjwqI9nmRm__p5XIWSZA86n4PJHjKPxUiS0wCvNx0FGEz1gbYqVjq9J0IGm5TnFQMKOo&usqp=CAU')),
          ),
          Text('Person'),
        ],
      ),
    );
  }
}
