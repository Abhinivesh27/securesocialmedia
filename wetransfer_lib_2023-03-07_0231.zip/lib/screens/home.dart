import 'package:demo/screens/action.dart';
import 'package:demo/screens/action2.dart';
import 'package:demo/screens/chat.dart';
import 'package:demo/screens/draw.dart';
import 'package:flutter/material.dart';

class HOME extends StatefulWidget {
  const HOME({super.key});

  @override
  State<HOME> createState() => _HOMEState();
}

class _HOMEState extends State<HOME> with SingleTickerProviderStateMixin {
  late TabController _controller;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TabController(length: 2, vsync: this, initialIndex: 0);
  }

  Widget build(BuildContext context) {
    return Scaffold(
        drawer: Drawer(
          backgroundColor: Colors.cyanAccent,
          child: Draw(),
        ),
        appBar: AppBar(
          backgroundColor: Colors.indigo,
          title: Text(
            'ATmega',
            style: TextStyle(color: Colors.amber, fontWeight: FontWeight.bold),
          ),
          actions: [
            IconButton(onPressed: () {}, icon: Icon(Icons.search)),
          ],
          bottom: TabBar(
            controller: _controller,
            tabs: [
              Tab(
                text: ' Chats',
              ),
              Tab(
                text: 'Calls',
              )
            ],
          ),
        ),
        body: TabBarView(
          controller: _controller,
          children: [Custom(), Custom2()],
        ));
  }
}
