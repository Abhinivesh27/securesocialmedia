import 'package:demo/models/callmodule.dart';
import 'package:flutter/material.dart';

class Call extends StatefulWidget {
  callModel call = callModel();
  Call({super.key, required callModel calldata}) {
    this.call = calldata;
  }

  @override
  State<Call> createState() => _CallState();
}

class _CallsState extends State<Call> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        child: Image(image: NetworkImage(widget.call.image)),
        backgroundColor: Colors.cyanAccent,
      ),
      title: Text(
        widget.call.userName,
        style: TextStyle(
          fontWeight: FontWeight.bold,
        ),
      ),
      subtitle: Row(
        children: [
          Text(
            widget.call.time,
            style: TextStyle(
              fontSize: 12,
            ),
          ),
        ],
      ),
      trailing: Icon(Icons.call),
    );
  }
}
