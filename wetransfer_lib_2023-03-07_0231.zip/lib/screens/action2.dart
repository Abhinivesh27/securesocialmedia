import 'package:demo/models/callmodule.dart';
import 'package:demo/screens/calls.dart';
import 'package:flutter/material.dart';

List<String> userName = [
  'Kowshik',
  'Person 1',
  'person 3',
  'person 4',
  'person 4',
  'person 5',
  'person 6',
];
List<String> time = [
  '12:00',
  '12:01 ',
  '12:02',
  '12:03',
  '12:04 ',
  '12:05 ',
  '12:06 ',
];

class Custom2 extends StatefulWidget {
  Custom2({super.key});
  List<callModel> call = List.generate(
      7,
      (index) => callModel()
        ..userName = userName[index]
        ..time = time[index]
        ..image =
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQNjwqI9nmRm__p5XIWSZA86n4PJHjKPxUiS0wCvNx0FGEz1gbYqVjq9J0IGm5TnFQMKOo&usqp=CAU');
  @override
  State<Custom2> createState() => _Custom2State();
}

class _Custom2State extends State<Custom2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {},
        child: Icon(Icons.add_call),
      ),
      body: ListView(children: [
        ...List.generate(
          7,
          (index) => Calls(
            calldata: call[index],
          ),
        )
      ]),
    );
  }
}
