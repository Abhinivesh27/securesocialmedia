import 'package:demo/models/chatmodule.dart';
import 'package:flutter/material.dart';

class Chat extends StatefulWidget {
  chatModel chat = chatModel();
  Chat({super.key, required chatModel chatdata}) {
    this.chat = chatdata;
  }
  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: CircleAvatar(
        child: Image(image: NetworkImage(widget.chat.image)),
        radius: 20,
        backgroundColor: Color.fromARGB(255, 227, 233, 233),
      ),
      title: Text(
        widget.chat.userName,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      subtitle: Row(
        children: [
          Icon(Icons.done_all),
          Text(widget.chat.message),
        ],
      ),
      trailing: Text(widget.chat.time),
    );
  }
}
