class chatModel {
  String userName = '';
  String message = '';
  String time = '';
  String image = '';
}
