class callModel {
  String userName = '';
  String image = '';
  String time = '';
  String calls = '';
}
